.onLoad <- function(libname, pkgname) {
    printInfo()
}
